/**
 * dashboard.js — MedTrack Pro
 * Dashboard page logic
 */

document.addEventListener('DOMContentLoaded', () => {
  DB.seedDemo();
  renderDashboard();
});

function renderDashboard() {
  const settings = DB.getSettings();
  const meds = DB.getMedicines().map(enrichMedicine);

  const total   = meds.length;
  const expired = meds.filter(m => m.status === 'expired');
  const warn    = meds.filter(m => m.status === 'warn');
  const safe    = meds.filter(m => m.status === 'safe');

  // Today date
  const todayEl = document.getElementById('todayDate');
  if (todayEl) {
    todayEl.textContent = new Date().toLocaleDateString('en-IN', { weekday:'long', year:'numeric', month:'long', day:'numeric' });
  }

  // Stats
  const grid = document.getElementById('statsGrid');
  if (grid) {
    grid.innerHTML = `
      <div class="stat-card total">
        <div class="stat-label">Total Medicines</div>
        <div class="stat-value">${total}</div>
        <div class="stat-trend">Across all categories</div>
      </div>
      <div class="stat-card safe">
        <div class="stat-label">Safe (>${settings.warnDays}d)</div>
        <div class="stat-value">${safe.length}</div>
        <div class="stat-trend">${total ? Math.round(safe.length/total*100) : 0}% of inventory</div>
      </div>
      <div class="stat-card warn">
        <div class="stat-label">Expiring Soon</div>
        <div class="stat-value">${warn.length}</div>
        <div class="stat-trend">Within ${settings.warnDays} days</div>
      </div>
      <div class="stat-card expired">
        <div class="stat-label">Expired</div>
        <div class="stat-value">${expired.length}</div>
        <div class="stat-trend">Needs immediate action</div>
      </div>
    `;
  }

  // Donut chart
  drawDonut(safe.length, warn.length, expired.length);

  // Expiring soon list
  const expiringList = document.getElementById('expiringList');
  if (expiringList) {
    const items = [...warn, ...expired].sort((a,b) => a.days - b.days).slice(0, 6);
    if (!items.length) {
      expiringList.innerHTML = '<div class="empty-state" style="padding:30px"><div class="empty-icon">✅</div><p>No medicines expiring soon!</p></div>';
    } else {
      expiringList.innerHTML = items.map(m => {
        const cls = m.status === 'expired' ? 'days-expired' : 'days-warn';
        return `<div class="expiring-item">
          <div>
            <div class="expiring-name">${esc(m.name)}</div>
            <div class="expiring-batch">${esc(m.batch)} · ${fmtExpiry(m.expiry)}</div>
          </div>
          <div class="expiring-days ${cls}">${fmtDays(m.days)}</div>
        </div>`;
      }).join('');
    }
  }

  // Recently added table
  const recentTable = document.getElementById('recentTable');
  if (recentTable) {
    const recent = [...meds].sort((a,b) => (b.createdAt||'').localeCompare(a.createdAt||'')).slice(0,5);
    if (!recent.length) {
      recentTable.innerHTML = '<div class="empty-state" style="padding:30px"><div class="empty-icon">💊</div><p>Add your first medicine to get started.</p></div>';
    } else {
      recentTable.innerHTML = `<table class="recent-table" style="width:100%">
        ${recent.map(m => `<tr>
          <td style="width:40%"><div class="med-name">${esc(m.name)}</div><div class="med-sub">${esc(m.category||'—')}</div></td>
          <td style="font-family:'DM Mono',monospace;font-size:0.8rem;color:var(--muted)">${esc(m.batch)||'—'}</td>
          <td style="font-family:'DM Mono',monospace;font-size:0.8rem">${fmtExpiry(m.expiry)}</td>
          <td><span class="status-pill status-${m.status}">${m.status==='expired'?'Expired':m.status==='warn'?'Soon':'Safe'}</span></td>
        </tr>`).join('')}
      </table>`;
    }
  }
}

function drawDonut(safe, warn, expired) {
  const canvas = document.getElementById('donutChart');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const total = safe + warn + expired;
  const cx = 100, cy = 100, r = 78, thick = 22;

  ctx.clearRect(0, 0, 200, 200);

  const segments = [
    { val: safe,    color: '#00e5a0' },
    { val: warn,    color: '#f59e0b' },
    { val: expired, color: '#ef4444' },
  ].filter(s => s.val > 0);

  if (!segments.length) {
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.strokeStyle = '#252a3a';
    ctx.lineWidth = thick;
    ctx.stroke();
  } else {
    let start = -Math.PI / 2;
    segments.forEach(seg => {
      const angle = (seg.val / total) * Math.PI * 2;
      ctx.beginPath();
      ctx.arc(cx, cy, r, start, start + angle);
      ctx.strokeStyle = seg.color;
      ctx.lineWidth = thick;
      ctx.lineCap = 'butt';
      ctx.stroke();
      start += angle;
    });
  }

  // Center total
  const center = document.getElementById('donutTotal');
  if (center) center.textContent = total;

  // Legend
  const legend = document.getElementById('chartLegend');
  if (legend) {
    legend.innerHTML = [
      { label:'Safe', color:'#00e5a0', val: safe },
      { label:'Soon', color:'#f59e0b', val: warn },
      { label:'Expired', color:'#ef4444', val: expired },
    ].map(l => `<div class="legend-item">
      <div class="legend-dot" style="background:${l.color}"></div>
      ${l.label} (${l.val})
    </div>`).join('');
  }
}
