/**
 * alerts.js — MedTrack Pro
 * Alerts page: expired, expiring soon, low stock
 */

document.addEventListener('DOMContentLoaded', () => {
  renderAlerts();
});

function renderAlerts() {
  const settings = DB.getSettings();
  const meds = DB.getMedicines().map(enrichMedicine);

  const expired   = meds.filter(m => m.status === 'expired').sort((a,b) => a.days - b.days);
  const warn      = meds.filter(m => m.status === 'warn').sort((a,b) => a.days - b.days);
  const lowStock  = meds.filter(m => m.qty <= settings.lowStockQty && m.qty >= 0).sort((a,b) => a.qty - b.qty);

  // Counts
  document.getElementById('expiredCount').textContent = `${expired.length} item${expired.length !== 1 ? 's' : ''}`;
  document.getElementById('warnCount').textContent    = `${warn.length} item${warn.length !== 1 ? 's' : ''}`;
  document.getElementById('lowStockCount').textContent = `${lowStock.length} item${lowStock.length !== 1 ? 's' : ''}`;

  // Alert stat cards
  const statsEl = document.getElementById('alertStats');
  if (statsEl) {
    statsEl.innerHTML = `
      <div class="stat-card expired">
        <div class="stat-label">Expired</div>
        <div class="stat-value">${expired.length}</div>
        <div class="stat-trend">Remove from shelves</div>
      </div>
      <div class="stat-card warn">
        <div class="stat-label">Expiring ≤${settings.warnDays}d</div>
        <div class="stat-value">${warn.length}</div>
        <div class="stat-trend">Prioritise sales</div>
      </div>
      <div class="stat-card total">
        <div class="stat-label">Low Stock</div>
        <div class="stat-value">${lowStock.length}</div>
        <div class="stat-trend">≤${settings.lowStockQty} units</div>
      </div>
    `;
  }

  renderAlertList('expiredList', expired, 'expired');
  renderAlertList('warnList', warn, 'warn');
  renderLowStockList('lowStockList', lowStock);
}

function renderAlertList(containerId, meds, type) {
  const el = document.getElementById(containerId);
  if (!el) return;

  if (!meds.length) {
    el.innerHTML = `<div class="empty-state" style="padding:30px"><div class="empty-icon">${type==='expired'?'✅':'🟢'}</div><p>No ${type==='expired'?'expired':'expiring'} medicines. Great!</p></div>`;
    return;
  }

  el.innerHTML = meds.map(m => {
    const daysCls = type === 'expired' ? 'days-expired' : 'days-warn';
    return `<div class="alert-item">
      <div class="alert-info">
        <div class="alert-name">${esc(m.name)}</div>
        <div class="alert-meta">
          Batch: ${esc(m.batch||'—')} &nbsp;·&nbsp;
          Expiry: ${fmtExpiry(m.expiry)} &nbsp;·&nbsp;
          Qty: ${m.qty}
          ${m.location ? ` &nbsp;·&nbsp; ${esc(m.location)}` : ''}
        </div>
      </div>
      <div class="alert-days ${daysCls}">${fmtDays(m.days)}</div>
      <button class="btn-del" onclick="deleteAlert(${m.id})">Remove</button>
    </div>`;
  }).join('');
}

function renderLowStockList(containerId, meds) {
  const el = document.getElementById(containerId);
  if (!el) return;

  if (!meds.length) {
    el.innerHTML = `<div class="empty-state" style="padding:30px"><div class="empty-icon">📦</div><p>All medicines are well-stocked.</p></div>`;
    return;
  }

  el.innerHTML = meds.map(m => `
    <div class="alert-item">
      <div class="alert-info">
        <div class="alert-name">${esc(m.name)}</div>
        <div class="alert-meta">
          Batch: ${esc(m.batch||'—')} &nbsp;·&nbsp;
          ${m.location ? `${esc(m.location)} &nbsp;·&nbsp;` : ''}
          Expiry: ${fmtExpiry(m.expiry)}
        </div>
      </div>
      <div class="alert-days" style="color:var(--warn);font-family:'DM Mono',monospace;font-size:0.9rem;font-weight:700">${m.qty} units</div>
    </div>`
  ).join('');
}

function deleteAlert(id) {
  if (!confirm('Remove this medicine from inventory?')) return;
  DB.deleteMedicine(id);
  renderAlerts();
  updateAlertBadge();
  showToast('🗑 Medicine removed.');
}

function exportAlertCSV() {
  const settings = DB.getSettings();
  const meds = DB.getMedicines().map(enrichMedicine)
    .filter(m => m.status !== 'safe')
    .sort((a,b) => a.days - b.days);

  if (!meds.length) { showToast('No alert data to export.'); return; }
  const csv = toCSV(meds, CSV_COLUMNS);
  downloadFile(`medtrack_alerts_${new Date().toISOString().slice(0,10)}.csv`, csv, 'text/csv');
  showToast('📥 Alerts CSV exported!');
}
