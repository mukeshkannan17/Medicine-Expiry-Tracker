/**
 * db.js — MedTrack Pro
 * Central data layer using localStorage
 */

const DB = (() => {
  const KEYS = {
    medicines: 'medtrack_medicines',
    settings:  'medtrack_settings',
  };

  const DEFAULT_SETTINGS = {
    pharmacyName: 'My Pharmacy',
    pharmacist:   '',
    license:      '',
    phone:        '',
    address:      '',
    warnDays:     30,
    lowStockQty:  10,
  };

  /* ---------- MEDICINES ---------- */

  function getMedicines() {
    try {
      return JSON.parse(localStorage.getItem(KEYS.medicines) || '[]');
    } catch { return []; }
  }

  function saveMedicines(list) {
    localStorage.setItem(KEYS.medicines, JSON.stringify(list));
  }

  function addMedicine(med) {
    const list = getMedicines();
    med.id = Date.now() + Math.floor(Math.random() * 1000);
    med.createdAt = new Date().toISOString();
    list.push(med);
    saveMedicines(list);
    return med;
  }

  function updateMedicine(id, updates) {
    const list = getMedicines();
    const idx = list.findIndex(m => m.id === id);
    if (idx === -1) return false;
    list[idx] = { ...list[idx], ...updates, updatedAt: new Date().toISOString() };
    saveMedicines(list);
    return list[idx];
  }

  function deleteMedicine(id) {
    const list = getMedicines().filter(m => m.id !== id);
    saveMedicines(list);
  }

  function getMedicineById(id) {
    return getMedicines().find(m => m.id === id) || null;
  }

  /* ---------- SETTINGS ---------- */

  function getSettings() {
    try {
      const stored = JSON.parse(localStorage.getItem(KEYS.settings) || '{}');
      return { ...DEFAULT_SETTINGS, ...stored };
    } catch { return { ...DEFAULT_SETTINGS }; }
  }

  function saveSettings(settings) {
    const current = getSettings();
    localStorage.setItem(KEYS.settings, JSON.stringify({ ...current, ...settings }));
  }

  /* ---------- BACKUP / RESTORE ---------- */

  function exportBackup() {
    return JSON.stringify({
      version: '2.0.0',
      exportedAt: new Date().toISOString(),
      medicines: getMedicines(),
      settings: getSettings(),
    }, null, 2);
  }

  function importBackup(json) {
    const data = JSON.parse(json);
    if (!data.medicines) throw new Error('Invalid backup file');
    saveMedicines(data.medicines);
    if (data.settings) saveSettings(data.settings);
    return data.medicines.length;
  }

  function clearAll() {
    localStorage.removeItem(KEYS.medicines);
  }

  /* ---------- SEED DEMO DATA ---------- */

  function seedDemo() {
    if (getMedicines().length > 0) return;
    const today = new Date();
    const fmt = (offset) => {
      const d = new Date(today.getFullYear(), today.getMonth() + offset, 1);
      return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;
    };

    const demo = [
      { name:'Paracetamol 500mg', category:'Analgesic',    batch:'BT-2024A', expiry: fmt(8),  qty:120, price:2.5,  location:'Rack A-1', mfr:'Cipla', notes:'' },
      { name:'Amoxicillin 250mg', category:'Antibiotic',   batch:'BT-2024B', expiry: fmt(2),  qty:60,  price:8.0,  location:'Rack B-2', mfr:'Sun Pharma', notes:'' },
      { name:'Metformin 500mg',   category:'Antidiabetic', batch:'BT-2023X', expiry: fmt(-2), qty:30,  price:5.0,  location:'Rack C-1', mfr:'Lupin', notes:'Check stock' },
      { name:'Cetirizine 10mg',   category:'Antiallergic', batch:'BT-2024C', expiry: fmt(1),  qty:8,   price:1.5,  location:'Rack A-3', mfr:'Mankind', notes:'' },
      { name:'Omeprazole 20mg',   category:'GI',           batch:'BT-2024D', expiry: fmt(14), qty:200, price:3.0,  location:'Rack D-1', mfr:'Cipla', notes:'' },
      { name:'Ibuprofen 400mg',   category:'Analgesic',    batch:'BT-2023Y', expiry: fmt(0),  qty:45,  price:4.0,  location:'Rack A-2', mfr:'Dr Reddys', notes:'' },
      { name:'Azithromycin 500mg',category:'Antibiotic',   batch:'BT-2024E', expiry: fmt(6),  qty:5,   price:12.0, location:'Rack B-1', mfr:'Alkem', notes:'' },
      { name:'Atorvastatin 10mg', category:'Cardiac',      batch:'BT-2024F', expiry: fmt(20), qty:150, price:6.5,  location:'Rack E-2', mfr:'Ranbaxy', notes:'' },
    ];

    demo.forEach(m => addMedicine(m));
  }

  return {
    getMedicines, saveMedicines, addMedicine, updateMedicine,
    deleteMedicine, getMedicineById,
    getSettings, saveSettings,
    exportBackup, importBackup, clearAll, seedDemo
  };
})();
